% Cristóbal Pascual, David
% Doncel Aparicio, Alberto

%Matriz A de conexiones
A=[0 0 0 0 0 0 0;
   0.333 0 0 0.5 0 0 0.5;
   0 0.5 0 0 0 0 0;
   0.333 0 0.5 0 0 0 0.5;
   0.333 0 0 0 0 0 0;
   0 0 0 0 0.5 0.5 0;
   0 0.5 0 0.5 0 0.5 0];